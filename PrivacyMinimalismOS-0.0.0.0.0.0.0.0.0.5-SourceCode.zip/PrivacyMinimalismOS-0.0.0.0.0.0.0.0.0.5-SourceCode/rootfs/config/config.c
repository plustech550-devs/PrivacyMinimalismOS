#include <stdio.h>

void load_config() {
    io_print("Loading PMOS configuration...\n");
}

void set_config_value(const char* key, const char* value) {
    printf("Config set: %s = %s\n", key, value);
}