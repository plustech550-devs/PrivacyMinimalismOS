#!/bin/bash
# Clean sensitive logs to maintain privacy
# Author: Gabriel Araújo de Barros
# Version: 0.0.0.0.0.0.0.0.0.3

LOG_DIR="/var/log"

echo "Cleaning logs in $LOG_DIR..."
find $LOG_DIR -type f -name "*.log" -exec shred -u {} \;
echo "Logs cleaned."