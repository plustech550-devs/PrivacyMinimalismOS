#!/bin/bash
# Minimal initialization script
echo "Initializing PMOS Phase 1..."
echo "Loading middlewares..."
# Simulate loading
sleep 1
echo "Middlewares loaded."