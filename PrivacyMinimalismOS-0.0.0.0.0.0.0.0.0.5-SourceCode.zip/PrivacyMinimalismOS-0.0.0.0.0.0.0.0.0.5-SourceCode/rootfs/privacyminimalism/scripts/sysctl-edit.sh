#!/usr/bin/env bash
# Safe edit: snapshot -> edit -> show diff -> sign diff -> append audit -> keep rollback info
# Usage: ./sysctl-edit.sh /path/to/system-file
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
SNAPSHOT_SCRIPT="$ROOT_DIR/scripts/snapshot.sh"
AUDIT_LOG="/var/log/privacyminimalism/pm_audit.log"
INSTALLER_KEY="/etc/pm-installer/installer.key"    # optional; on installer media
TMPDIR="/var/tmp/privacyminimalism"
EDITOR="${EDITOR:-vi}"

mkdir -p "$TMPDIR"
mkdir -p "$(dirname "$AUDIT_LOG")"

FILE="$1"
if [ -z "$FILE" ]; then
  echo "Usage: $0 /path/to/system-file"
  exit 2
fi
if [ ! -f "$FILE" ]; then
  echo "File not found: $FILE"
  exit 3
fi

# Step 1: snapshot
SNAPPATH="$("$SNAPSHOT_SCRIPT" "before-edit-$(basename "$FILE")")"
echo "Snapshot created: $SNAPPATH"

# Step 2: backup current copy for diff
BEFORE_COPY="$TMPDIR/$(basename "$FILE").before.$(date +%s)"
cp --preserve=all "$FILE" "$BEFORE_COPY"

# Step 3: edit
"$EDITOR" "$FILE"

# Step 4: generate diff
DIFFFILE="$TMPDIR/$(basename "$FILE").diff.$(date +%s)"
if ! diff -u "$BEFORE_COPY" "$FILE" > "$DIFFFILE" 2>/dev/null; then
  # diff returns non-zero when differences exist; but we still have the file
  true
fi

if [ ! -s "$DIFFFILE" ]; then
  echo "No changes detected. Cleaning up."
  rm -f "$BEFORE_COPY" "$DIFFFILE"
  exit 0
fi

echo "Diff written to $DIFFFILE"
echo "----------------"
sed -n '1,200p' "$DIFFFILE"
echo "----------------"

# Step 5: sign diff if key present
SIGFILE="${DIFFFILE}.sig"
if [ -f "$INSTALLER_KEY" ]; then
  openssl dgst -sha256 -sign "$INSTALLER_KEY" -out "$SIGFILE" "$DIFFFILE" || true
  if [ -f "$SIGFILE" ]; then
    echo "Diff signed -> $SIGFILE"
  fi
else
  echo "Installer key not found at $INSTALLER_KEY — skipping signature."
fi

# Step 6: append audit entry (tamper-evident-ish)
TIMESTAMP="$(date --utc +%Y-%m-%dT%H:%M:%SZ)"
USER="$(id -un || echo unknown)"
SNAP_ID="$(basename "$SNAPPATH")"
AUDIT_ENTRY="$(jq -n \
  --arg t "$TIMESTAMP" \
  --arg u "$USER" \
  --arg f "$FILE" \
  --arg s "$SNAP_ID" \
  --arg d "$(head -c 4096 "$DIFFFILE" | base64 -w0)" \
  '{time:$t, user:$u, file:$f, snapshot:$s, diff_b64:$d}')"

echo "$AUDIT_ENTRY" >> "$AUDIT_LOG"
echo "Audit appended to $AUDIT_LOG"

# Step 7: provide helpful next steps
echo
echo "Edit applied. If anything goes wrong you can rollback to snapshot: $SNAPPATH"
echo "To inspect the diff: less $DIFFFILE"
if [ -f "$SIGFILE" ]; then
  echo "Signature: $SIGFILE"
fi

exit 0