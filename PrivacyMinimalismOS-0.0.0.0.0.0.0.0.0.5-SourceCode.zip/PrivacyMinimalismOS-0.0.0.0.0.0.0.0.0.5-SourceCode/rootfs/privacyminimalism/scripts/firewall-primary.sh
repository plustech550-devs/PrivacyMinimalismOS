#!/bin/bash
# PrivacyMinimalismOS Firewall - primary user network enforcement
# Author: Gabriel Araújo de Barros
# Version: 0.0.0.0.0.0.0.0.0.3

# Ensure ufw is installed
if ! command -v ufw &> /dev/null; then
    echo "UFW not found. Installing..."
    apt-get update && apt-get install -y ufw
fi

# Set default policies
ufw default deny incoming
ufw default allow outgoing

# Allow SSH from LAN only
ufw allow from 192.168.0.0/24 to any port 22 comment 'Allow SSH from LAN'

# Enable UFW
ufw --force enable

echo "Firewall setup complete."