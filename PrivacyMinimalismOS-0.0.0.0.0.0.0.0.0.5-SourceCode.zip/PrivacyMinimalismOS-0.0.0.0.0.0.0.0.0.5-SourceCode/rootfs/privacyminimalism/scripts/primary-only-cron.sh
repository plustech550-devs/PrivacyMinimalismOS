#!/bin/bash
# Remove cron jobs for all users except primary
# Author: Gabriel Araújo de Barros
# Version: 0.0.0.0.0.0.0.0.0.3

PRIMARY_USER="primary"

# Iterate over all normal users
for user in $(awk -F: '$3>=1000{print $1}' /etc/passwd); do
    if [ "$user" != "$PRIMARY_USER" ]; then
        crontab -r -u "$user" 2>/dev/null
        echo "Removed cron jobs for $user"
    fi
done