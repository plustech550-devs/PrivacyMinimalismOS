#!/bin/bash
# Audit critical files for unauthorized changes
# Author: Gabriel Araújo de Barros
# Version: 0.0.0.0.0.0.0.0.0.3

AUDIT_LOG="/var/log/privacyminimalism_audit.log"

echo "----- Audit Run: $(date) -----" >> $AUDIT_LOG

CRITICAL_FILES=(
    "/etc/sudoers.d/primary-only"
    "/etc/passwd"
    "/etc/shadow"
    "/etc/selinux"
)

for file in "${CRITICAL_FILES[@]}"; do
    if [ -f "$file" ]; then
        sha256sum "$file" >> $AUDIT_LOG
    else
        echo "$file missing!" >> $AUDIT_LOG
    fi
done

echo "Audit complete."