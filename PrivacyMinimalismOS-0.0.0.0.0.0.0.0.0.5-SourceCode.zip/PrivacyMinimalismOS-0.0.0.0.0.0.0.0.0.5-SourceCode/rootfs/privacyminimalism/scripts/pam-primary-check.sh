#!/usr/bin/env bash
# PAM helper: returns 0 if provided username matches primary mapping
# Usage: pam-primary-check.sh <username>
set -euo pipefail

MAP="/boot/PrivacyMinimalism/primary-user-mapping"
USERNAME="${1:-}"

if [ -z "$USERNAME" ] || [ ! -f "$MAP" ]; then
  exit 1
fi

MAP_USERNAME="$(cut -d: -f1 "$MAP" | tr -d '[:space:]')"
if [ "$USERNAME" = "$MAP_USERNAME" ]; then
  exit 0
else
  exit 1
fi