#include <stdio.h>

void fs_init() {
    io_print("Initializing minimal filesystem...\n");
}

void fs_create_file(const char* name) {
    printf("Created file: %s\n", name);
}

void fs_read_file(const char* name) {
    printf("Reading file: %s (stub)\n", name);
}