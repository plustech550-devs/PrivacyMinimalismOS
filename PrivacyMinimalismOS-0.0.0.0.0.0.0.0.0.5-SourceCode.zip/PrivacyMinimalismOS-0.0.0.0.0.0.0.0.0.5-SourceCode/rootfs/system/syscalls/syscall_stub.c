// Minimal system call stubs
int syscall_test(int value) {
    // Just returns the value + 1 for testing
    return value + 1;
}