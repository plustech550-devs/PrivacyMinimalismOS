#include <stdio.h>
#include <string.h>

void cli_loop() {
    char input[64];
    io_print("PMOS CLI> ");
    while (1) {
        fgets(input, sizeof(input), stdin);
        if (strncmp(input, "exit", 4) == 0) {
            io_print("Exiting CLI...\n");
            break;
        } else if (strncmp(input, "hello", 5) == 0) {
            io_print("Hello from PMOS Phase 1!\n");
        } else {
            io_print("Unknown command\n");
        }
        io_print("PMOS CLI> ");
    }
}