#include <stdio.h>

void io_print(const char* msg) {
    printf("%s", msg);
}

void io_print_int(int n) {
    printf("%d", n);
}