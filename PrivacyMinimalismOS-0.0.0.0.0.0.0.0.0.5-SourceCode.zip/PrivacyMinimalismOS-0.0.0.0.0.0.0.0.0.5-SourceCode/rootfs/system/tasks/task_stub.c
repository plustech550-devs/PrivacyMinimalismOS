#include <stdio.h>

void task_example() {
    io_print("Running a sample task...\n");
}