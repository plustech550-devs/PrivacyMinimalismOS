// Minimal instruction set definitions
#ifndef INSTRUCTIONS_H
#define INSTRUCTIONS_H

#define PMOS_NOP 0x00
#define PMOS_HALT 0xFF

#endif