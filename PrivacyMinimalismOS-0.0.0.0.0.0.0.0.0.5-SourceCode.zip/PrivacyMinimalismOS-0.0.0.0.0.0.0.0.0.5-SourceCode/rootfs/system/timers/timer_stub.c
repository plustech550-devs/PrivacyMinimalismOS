#include <stdio.h>
#include <unistd.h>

void timer_start() {
    io_print("Starting minimal timer (stub)...\n");
}

void timer_tick() {
    io_print("Timer tick...\n");
}