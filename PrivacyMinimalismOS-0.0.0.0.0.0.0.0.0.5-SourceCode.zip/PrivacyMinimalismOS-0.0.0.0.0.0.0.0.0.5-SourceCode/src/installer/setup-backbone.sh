#!/bin/bash
# Setup all backbone scripts for PrivacyMinimalismOS
# Author: Gabriel Araújo de Barros
# Version: 0.0.0.0.0.0.0.0.0.3

set -e

echo "Starting backbone setup..."

bash installer/install.sh
bash privacyminimalism/scripts/sysctl-edit.sh
bash privacyminimalism/scripts/firewall-primary.sh
bash privacyminimalism/scripts/pam-primary-check.sh
bash privacyminimalism/scripts/primary-only-cron.sh
bash privacyminimalism/scripts/audit-primary.sh
bash privacyminimalism/scripts/log-cleanup.sh

echo "Backbone setup complete. PrivacyMinimalismOS is ready."