#!/usr/bin/env bash
set -euo pipefail
if [ $# -lt 1 ]; then
  echo "Usage: $0 <primary-username>"
  exit 2
fi
PRIMARY_USERNAME="$1"
BOOT_EFI_DIR="/boot/PrivacyMinimalism"
INSTALLER_KEY="/etc/pm-installer/installer.key"

mkdir -p "$BOOT_EFI_DIR"
PRIMARY_UUID="$(uuidgen)"
echo "${PRIMARY_USERNAME}:${PRIMARY_UUID}" > "$BOOT_EFI_DIR/primary-user-mapping"
chmod 600 "$BOOT_EFI_DIR/primary-user-mapping"
chown root:root "$BOOT_EFI_DIR/primary-user-mapping"

# store UID mapping too (optional)
USER_UID="$(id -u "$PRIMARY_USERNAME" 2>/dev/null || true)"
if [ -n "$USER_UID" ]; then
  echo "${PRIMARY_USERNAME}:${PRIMARY_UUID}:${USER_UID}" > "$BOOT_EFI_DIR/primary-user-mapping-uid"
  chmod 600 "$BOOT_EFI_DIR/primary-user-mapping-uid"
fi

# sign mapping if installer key exists
if [ -f "$INSTALLER_KEY" ]; then
  openssl dgst -sha256 -sign "$INSTALLER_KEY" -out "$BOOT_EFI_DIR/primary-user-mapping.sig" "$BOOT_EFI_DIR/primary-user-mapping" || true
fi

echo "Primary user registered: $PRIMARY_USERNAME -> $PRIMARY_UUID"