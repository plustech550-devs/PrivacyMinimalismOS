// Minimal bootloader for testing
#include <stdint.h>

void bootloader_main() {
    // Just simulate boot message
    volatile char* video = (volatile char*)0xB8000;
    *video = 'P';       // Display 'P'
    *(video+1) = 0x07;  // Light grey on black
    *(video+2) = 'M';
    *(video+3) = 0x07;
    *(video+4) = 'O';
    *(video+5) = 0x07;
    *(video+6) = 'S';
    *(video+7) = 0x07;
    // Then jump to kernel (simulated)
}

void _boot() {
    bootloader_main();
    // In a real bootloader, here we'd jump to kernel
}