#include <stdint.h>
#include "../middlewares/simple_io.c"
#include "../middlewares/cli.c"
#include "../syscalls/syscall_stub.c"
#include "../fs/fs_stub.c"
#include "../tasks/task_stub.c"
#include "../timers/timer_stub.c"
#include "../config/config.c"

void kernel_main() {
    io_print("PMOS Phase 1 - Build 0.0.0.0.0.0.0.0.0.5\n");

    load_config();
    fs_init();
    timer_start();

    int result = syscall_test(42);
    io_print("Syscall returned: ");
    io_print_int(result);
    io_print("\n");

    task_example(); // Run sample task
    cli_loop(); // Enter minimal CLI

    io_print("Kernel test finished.\n");
}

void _start() {
    kernel_main();
    while (1); // Loop forever
}